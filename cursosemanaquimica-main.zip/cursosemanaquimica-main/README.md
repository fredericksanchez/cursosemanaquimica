# cursosemanaquimica
